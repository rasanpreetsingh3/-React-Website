import React from 'react';
import './master.css';

function BannerImage() {
  return (
    <div>
      <img src="../images/banner.jpg" className="banner" alt="banner" />
    </div>
  )
}

export default BannerImage;
